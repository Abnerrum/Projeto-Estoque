import pytest
from app import create_app, db
from app.models.usuario import Usuario
from app.models.produto import Produto, Categoria
from app.models.movimentacao import Movimentacao


@pytest.fixture
def app():
    app = create_app("testing")
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def usuario(app):
    with app.app_context():
        u = Usuario(nome="Teste", email="teste@teste.com", admin=True)
        u.set_senha("123456")
        db.session.add(u)
        db.session.commit()
        return u


def login(client, email="teste@teste.com", senha="123456"):
    return client.post("/auth/login", data={"email": email, "senha": senha},
                       follow_redirects=True)


# ── Auth ────────────────────────────────────────────────────────────────────

def test_login_sucesso(client, usuario):
    resp = login(client)
    assert resp.status_code == 200
    assert "Bem-vindo" in resp.data.decode()


def test_login_senha_errada(client, usuario):
    resp = client.post("/auth/login", data={"email": "teste@teste.com", "senha": "errada"},
                       follow_redirects=True)
    assert "incorretos" in resp.data.decode()


def test_rota_protegida_sem_login(client):
    resp = client.get("/produtos/", follow_redirects=True)
    assert "login" in resp.request.path or b"login" in resp.data.lower()


# ── Produtos ────────────────────────────────────────────────────────────────

def test_criar_produto(client, usuario):
    login(client)
    resp = client.post("/produtos/novo", data={
        "codigo": "PROD-001",
        "nome": "Produto Teste",
        "descricao": "Desc",
        "unidade": "un",
        "estoque_minimo": "5",
        "categoria_id": "",
    }, follow_redirects=True)
    assert resp.status_code == 200
    assert b"cadastrado" in resp.data


def test_codigo_duplicado(client, usuario, app):
    login(client)
    with app.app_context():
        p = Produto(nome="Existente", codigo="DUP-001")
        db.session.add(p)
        db.session.commit()

    resp = client.post("/produtos/novo", data={
        "codigo": "DUP-001", "nome": "Outro", "unidade": "un",
        "estoque_minimo": "0", "categoria_id": "",
    }, follow_redirects=True)
    assert b"c\xc3\xb3digo" in resp.data or b"j\xc3\xa1 existe" in resp.data.lower()


# ── Saldo ────────────────────────────────────────────────────────────────────

def test_saldo_inicial_zero(app, usuario):
    with app.app_context():
        p = Produto(nome="P", codigo="TST-001")
        db.session.add(p)
        db.session.commit()
        assert p.saldo_atual == 0


def test_saldo_apos_entrada(app, usuario):
    with app.app_context():
        u = Usuario.query.first()
        p = Produto(nome="P", codigo="TST-002")
        db.session.add(p)
        db.session.commit()

        m = Movimentacao(tipo="entrada", quantidade=10, produto_id=p.id, usuario_id=u.id)
        db.session.add(m)
        db.session.commit()
        assert p.saldo_atual == 10


def test_saldo_apos_saida(app, usuario):
    with app.app_context():
        u = Usuario.query.first()
        p = Produto(nome="P", codigo="TST-003")
        db.session.add(p)
        db.session.commit()

        db.session.add(Movimentacao(tipo="entrada", quantidade=20, produto_id=p.id, usuario_id=u.id))
        db.session.add(Movimentacao(tipo="saida",   quantidade=8,  produto_id=p.id, usuario_id=u.id))
        db.session.commit()
        assert p.saldo_atual == 12


def test_bloqueia_saida_sem_saldo(client, usuario, app):
    login(client)
    with app.app_context():
        p = Produto(nome="Vazio", codigo="TST-004")
        db.session.add(p)
        db.session.commit()
        pid = p.id

    resp = client.post("/movimentacoes/nova", data={
        "tipo": "saida", "quantidade": "5",
        "produto_id": str(pid), "justificativa": "",
    }, follow_redirects=True)
    assert "insuficiente" in resp.data.decode()


def test_produto_abaixo_minimo(app, usuario):
    with app.app_context():
        u = Usuario.query.first()
        p = Produto(nome="P", codigo="TST-005", estoque_minimo=10)
        db.session.add(p)
        db.session.commit()

        db.session.add(Movimentacao(tipo="entrada", quantidade=5, produto_id=p.id, usuario_id=u.id))
        db.session.commit()
        assert p.abaixo_minimo is True
